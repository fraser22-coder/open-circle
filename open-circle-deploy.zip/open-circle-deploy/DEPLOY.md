# Open Circle — Deployment Package

## What's in this package

All new and updated files from your The Circle build session. Replace the corresponding files in your local repo with these — then push to GitHub and Vercel will deploy automatically.

---

## Files changed

### Core security & infrastructure
- `src/lib/adminAuth.ts` — HttpOnly cookie admin auth
- `src/lib/rateLimit.ts` — in-memory rate limiting
- `src/lib/sanitize.ts` — input sanitization helpers
- `src/lib/types.ts` — updated type definitions (added brief_vendors)
- `src/lib/email.ts` — updated email templates
- `src/lib/supabase.ts` — supabase client
- `src/middleware.ts` — security headers + bot blocking
- `next.config.mjs` — hardened Next.js config

### API routes
- `src/app/api/admin/login/route.ts` — admin login endpoint
- `src/app/api/admin/logout/route.ts` — admin logout endpoint
- `src/app/api/enquiries/route.ts` — enquiry submission (POST) + admin CRUD
- `src/app/api/vendor-applications/route.ts` — vendor applications
- `src/app/api/vendor-responses/route.ts` — vendor availability responses (NEW)
- `src/app/api/vendors/route.ts` — vendor CRUD (admin protected)
- `src/app/api/vendors/[slug]/route.ts` — single vendor lookup (NEW)

### Admin
- `src/app/admin/page.tsx` — server component with cookie auth + redirect
- `src/app/admin/AdminDashboard.tsx` — client admin UI
- `src/app/admin/login/page.tsx` — admin login form

### Vendor portal
- `src/app/vendor/dashboard/page.tsx` — vendor dashboard (privacy fix + response buttons)

### Public pages
- `src/app/page.tsx` — full homepage (replaces old redirect)
- `src/app/not-found.tsx` — custom 404 page (NEW)
- `src/app/robots.ts` — updated with all routes
- `src/app/sitemap.ts` — updated sitemap (includes new pages + uses env var for base URL)
- `src/app/privacy/page.tsx` — Privacy Policy page (NEW)
- `src/app/terms/page.tsx` — Terms of Service page (NEW)
- `src/app/how-it-works/page.tsx` — How It Works page (NEW)
- `src/app/book/page.tsx` — booking form (brief cart + honeypot)

### Vendor profiles
- `src/app/circle/[slug]/page.tsx` — JSON-LD + fixed base URL
- `src/app/circle/[slug]/VendorProfileClient.tsx` — gallery lightbox + brief cart

### Components
- `src/components/NavBar.tsx` — brief cart drawer + logo fix

---

## Environment variables to set in Vercel

Make sure these are set in your Vercel project settings:

```
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
RESEND_API_KEY=your-resend-key
ADMIN_SECRET=your-strong-random-password   ← NEW (do NOT use NEXT_PUBLIC_)
ADMIN_EMAIL=your@email.com
NEXT_PUBLIC_SITE_URL=https://thecircle.opencirclemarkets.com
```

---

## Supabase migrations to run

Run these in the Supabase SQL editor if you haven't already:

```sql
-- Add brief_vendors column to enquiries
ALTER TABLE enquiries ADD COLUMN IF NOT EXISTS brief_vendors jsonb DEFAULT '[]';

-- Create vendor_responses table
CREATE TABLE IF NOT EXISTS vendor_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enquiry_id uuid REFERENCES enquiries(id) ON DELETE CASCADE,
  vendor_id uuid REFERENCES vendors(id) ON DELETE CASCADE,
  status text CHECK (status IN ('available', 'unavailable')),
  message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(enquiry_id, vendor_id)
);

-- Optional: RLS policy for vendor_responses (vendors can see their own)
ALTER TABLE vendor_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Vendors can read own responses"
  ON vendor_responses FOR SELECT
  USING (vendor_id IN (
    SELECT id FROM vendors WHERE user_id = auth.uid()
  ));
```
